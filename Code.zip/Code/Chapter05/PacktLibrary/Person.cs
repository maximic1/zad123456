﻿using System;

namespace Packt.Shared
{
    public class Person : Object
    {
        public string Name;
        public DateTime DateOfBirth;
    }
}
